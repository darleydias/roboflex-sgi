-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 19-Dez-2022 às 03:48
-- Versão do servidor: 10.4.24-MariaDB
-- versão do PHP: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `sistema`
--
CREATE DATABASE IF NOT EXISTS `sistema` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `sistema`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `back_order_list`
--

CREATE TABLE IF NOT EXISTS `back_order_list` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `receiving_id` int(30) NOT NULL,
  `po_id` int(30) NOT NULL,
  `bo_code` varchar(50) NOT NULL,
  `supplier_id` int(30) NOT NULL,
  `amount` float NOT NULL,
  `discount_perc` float NOT NULL DEFAULT 0,
  `discount` float NOT NULL DEFAULT 0,
  `tax_perc` float NOT NULL DEFAULT 0,
  `tax` float NOT NULL DEFAULT 0,
  `remarks` text DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0 COMMENT '0 = pending, 1 = partially received, 2 =received',
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `supplier_id` (`supplier_id`),
  KEY `po_id` (`po_id`),
  KEY `receiving_id` (`receiving_id`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `bo_items`
--

CREATE TABLE IF NOT EXISTS `bo_items` (
  `bo_id` int(30) NOT NULL,
  `item_id` int(30) NOT NULL,
  `quantity` int(30) NOT NULL,
  `price` float NOT NULL DEFAULT 0,
  `unit` varchar(50) NOT NULL,
  `total` float NOT NULL DEFAULT 0,
  KEY `item_id` (`item_id`),
  KEY `bo_id` (`bo_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `categoria_compra_list`
--

CREATE TABLE IF NOT EXISTS `categoria_compra_list` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `categoria_compra_list`
--

INSERT INTO `categoria_compra_list` (`id`, `name`, `status`, `date_created`, `date_updated`) VALUES
(1, 'Matérias Primas', 1, '2022-10-26 11:46:23', '2022-11-25 08:42:56'),
(2, 'Administração', 1, '2022-10-26 11:46:23', '2022-11-25 08:43:14'),
(3, 'Material de Escritório', 1, '2022-11-25 08:43:47', '2022-11-25 08:43:47'),
(4, 'Veículos', 1, '2022-11-25 08:44:03', '2022-11-25 08:44:03'),
(5, 'Categoria teste', 1, '2022-12-06 17:03:17', '2022-12-06 17:03:17');

-- --------------------------------------------------------

--
-- Estrutura da tabela `cotacao_list`
--

CREATE TABLE IF NOT EXISTS `cotacao_list` (
  `po_id` int(11) NOT NULL,
  `item_id` int(11) NOT NULL,
  `cotacao_1_0` varchar(50) NOT NULL,
  `cotacao_1_1` int(11) NOT NULL,
  `cotacao_1_2` int(11) NOT NULL,
  KEY `po_id` (`po_id`),
  KEY `item_id` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `fornecedor_cat`
--

CREATE TABLE IF NOT EXISTS `fornecedor_cat` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `fornecedor_cat`
--

INSERT INTO `fornecedor_cat` (`id`, `name`, `status`, `date_created`, `date_updated`) VALUES
(1, 'Cat forn 01', 1, '2022-11-04 16:31:38', '2022-11-04 16:31:38'),
(2, 'Cat Forn 02', 1, '2022-11-04 16:31:38', '2022-11-04 16:31:38');

-- --------------------------------------------------------

--
-- Estrutura da tabela `fornecedor_list`
--

CREATE TABLE IF NOT EXISTS `fornecedor_list` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `pessoa_fornecedor` varchar(30) NOT NULL,
  `tel_fornecedor` varchar(20) NOT NULL,
  `email_fornecedor` varchar(30) NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `fornecedor_cat_id` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `fornecedor_cat_id` (`fornecedor_cat_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `fornecedor_list`
--

INSERT INTO `fornecedor_list` (`id`, `name`, `pessoa_fornecedor`, `tel_fornecedor`, `email_fornecedor`, `status`, `date_created`, `date_updated`, `fornecedor_cat_id`) VALUES
(2, 'Fornecedor 01', 'Raul', '31912341234', 'raul@email.com.br', 1, '2022-11-04 16:32:35', '2022-11-04 16:32:35', 1),
(3, 'Fornecedor 02', 'raul 2', '315552455', 'raul2@gmail.com', 1, '2022-11-04 16:32:35', '2022-11-04 16:32:35', 2);

-- --------------------------------------------------------

--
-- Estrutura da tabela `item_list`
--

CREATE TABLE IF NOT EXISTS `item_list` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `description` text NOT NULL,
  `cod_item` varchar(50) DEFAULT NULL,
  `supplier_id` int(30) NOT NULL,
  `cost` float NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `mat_ou_ser` tinyint(1) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `supplier_id` (`supplier_id`)
) ENGINE=InnoDB AUTO_INCREMENT=69 DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `item_list`
--

INSERT INTO `item_list` (`id`, `name`, `description`, `cod_item`, `supplier_id`, `cost`, `status`, `mat_ou_ser`, `date_created`, `date_updated`) VALUES
(63, 'Material 01', '', 'cst-50015', 9, 0, 1, 1, '2022-11-17 13:38:13', '2022-11-17 13:38:13'),
(64, 'Material 02', '', 'CST-10055', 9, 0, 1, 1, '2022-11-17 13:38:23', '2022-11-17 13:38:23'),
(65, 'Mouse', 'desc', 'codigo mouse', 7, 100, 1, 1, '2022-11-17 16:27:52', '2022-11-25 08:39:54'),
(66, 'Teclado', 'teclado para uso', 'cod', 7, 500, 1, 1, '2022-11-25 08:40:19', '2022-11-25 08:40:19'),
(67, 'Máquinas', 'teste', 'codigo', 8, 0, 1, 0, '2022-11-25 08:55:47', '2022-11-25 08:55:47'),
(68, 'Giga de teste', 'teste', 'código', 10, 0, 1, 0, '2022-11-25 08:56:20', '2022-11-25 08:56:20');

-- --------------------------------------------------------

--
-- Estrutura da tabela `po_items`
--

CREATE TABLE IF NOT EXISTS `po_items` (
  `po_id` int(30) NOT NULL,
  `item_id` int(30) NOT NULL,
  `quantity` int(30) NOT NULL,
  `price` float NOT NULL DEFAULT 0,
  `unit` varchar(50) NOT NULL,
  `total` float NOT NULL DEFAULT 0,
  `obs_item` varchar(150) NOT NULL,
  `prev_data` date DEFAULT NULL,
  `fornecedor_item` varchar(30) NOT NULL,
  `cotacao_1_0` varchar(50) NOT NULL,
  `cotacao_1_1` int(11) NOT NULL,
  `cotacao_1_2` int(11) NOT NULL,
  `cotacao_2_0` varchar(50) NOT NULL,
  `cotacao_2_1` int(11) NOT NULL,
  `cotacao_2_2` int(11) NOT NULL,
  `cotacao_3_0` varchar(50) NOT NULL,
  `cotacao_3_1` int(11) NOT NULL,
  `cotacao_3_2` int(11) NOT NULL,
  `botao_cot1` tinyint(2) NOT NULL,
  KEY `po_id` (`po_id`),
  KEY `item_id` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `po_items`
--

INSERT INTO `po_items` (`po_id`, `item_id`, `quantity`, `price`, `unit`, `total`, `obs_item`, `prev_data`, `fornecedor_item`, `cotacao_1_0`, `cotacao_1_1`, `cotacao_1_2`, `cotacao_2_0`, `cotacao_2_1`, `cotacao_2_2`, `cotacao_3_0`, `cotacao_3_1`, `cotacao_3_2`, `botao_cot1`) VALUES
(183, 65, 55, 0, 'Caixa', 0, 'obs1', '2022-12-14', 'ind1', '', 0, 0, '', 0, 0, '', 0, 0, 0),
(184, 65, 55, 0, 'Und', 0, 'obs', '2022-12-21', 'indc', '', 0, 0, '', 0, 0, '', 0, 0, 0),
(185, 65, 55, 0, 'M', 0, 'obs', '2022-12-15', 'ind', '', 0, 0, '', 0, 0, '', 0, 0, 0),
(186, 65, 5, 0, 'Caixa', 0, 'asdasd', '2022-12-29', 'Fornecedor 01', '', 0, 0, '', 0, 0, '', 0, 0, 0),
(187, 65, 6, 0, 'Caixa', 0, 'obs', '2022-12-23', 'Fornecedor 01', '', 0, 0, '', 0, 0, '', 0, 0, 0),
(187, 66, 4, 0, 'Und', 0, 'obs', '2022-12-16', 'Fornecedor 02', '', 0, 0, '', 0, 0, '', 0, 0, 0),
(188, 65, 55, 0, 'Caixa', 0, 'obs', '2022-12-21', 'Fornecedor 02', '', 0, 0, '', 0, 0, '', 0, 0, 0),
(188, 66, 55, 0, 'Und', 0, 'obs', '2022-12-23', 'Fornecedor 01', '', 0, 0, '', 0, 0, '', 0, 0, 0),
(189, 65, 5, 0, 'Und', 0, 'OBS', '2022-12-15', 'Fornecedor 01', '', 0, 0, '', 0, 0, '', 0, 0, 0),
(190, 65, 4, 0, 'Und', 0, 'obs', '2022-12-21', 'Fornecedor 01', '', 0, 0, '', 0, 0, '', 0, 0, 0),
(191, 65, 5, 0, 'Cm', 0, 'obs', '2022-12-13', 'Fornecedor 01', '', 0, 0, '', 0, 0, '', 0, 0, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `purchase_order_list`
--

CREATE TABLE IF NOT EXISTS `purchase_order_list` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `po_code` varchar(50) NOT NULL,
  `supplier_id` int(30) NOT NULL,
  `mat_ou_ser_op` tinyint(1) NOT NULL,
  `amount` float NOT NULL,
  `discount_perc` float NOT NULL DEFAULT 0,
  `discount` float NOT NULL DEFAULT 0,
  `tax_perc` float NOT NULL DEFAULT 0,
  `tax` float NOT NULL DEFAULT 0,
  `remarks` text NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0 COMMENT '0 = pending, 1 = partially received, 2 =received',
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `req_unidade` tinyint(1) NOT NULL DEFAULT 1,
  `req_projeto` tinyint(1) NOT NULL DEFAULT 1,
  `sepo_code` varchar(50) NOT NULL,
  `req_date` date DEFAULT NULL,
  `req_requisitante` int(11) NOT NULL,
  `req_cat_compra` int(11) NOT NULL,
  `req_setor_util` int(11) NOT NULL,
  `req_proj_nome` varchar(25) NOT NULL,
  `req_proj_cod` varchar(25) NOT NULL,
  `req_motivacao` varchar(250) NOT NULL,
  `etapa_mat_ou_ser` tinyint(2) NOT NULL,
  `etapa_solicitacao` tinyint(2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `supplier_id` (`supplier_id`)
) ENGINE=InnoDB AUTO_INCREMENT=192 DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `purchase_order_list`
--

INSERT INTO `purchase_order_list` (`id`, `po_code`, `supplier_id`, `mat_ou_ser_op`, `amount`, `discount_perc`, `discount`, `tax_perc`, `tax`, `remarks`, `status`, `date_created`, `date_updated`, `req_unidade`, `req_projeto`, `sepo_code`, `req_date`, `req_requisitante`, `req_cat_compra`, `req_setor_util`, `req_proj_nome`, `req_proj_cod`, `req_motivacao`, `etapa_mat_ou_ser`, `etapa_solicitacao`) VALUES
(183, 'RQC-0001', 7, 0, 0, 0, 0, 0, 0, '', 2, '2022-12-14 21:00:24', '2022-12-14 21:00:29', 1, 1, '', '2022-12-14', 4, 5, 2, '', '', '', 0, 0),
(184, 'RQC-0002', 7, 0, 0, 0, 0, 0, 0, '', 2, '2022-12-14 21:03:54', '2022-12-14 21:03:59', 1, 1, '', '2022-12-14', 6, 3, 3, '', '', '', 0, 0),
(185, 'RQC-0003', 7, 0, 0, 0, 0, 0, 0, '', 2, '2022-12-14 21:12:08', '2022-12-14 21:12:13', 1, 1, '', '2022-12-14', 5, 3, 2, '', '', '', 0, 0),
(186, 'RQC-0004', 7, 0, 0, 0, 0, 0, 0, '', 2, '2022-12-18 12:33:25', '2022-12-18 12:33:56', 0, 1, '', '2022-12-18', 4, 3, 2, '', '', '', 0, 0),
(187, 'RQC-0005', 7, 0, 0, 0, 0, 0, 0, '', 2, '2022-12-18 12:36:46', '2022-12-18 12:36:51', 0, 1, '', '2022-12-18', 6, 2, 3, '', '', '', 0, 0),
(188, 'RQC-0006', 7, 0, 0, 0, 0, 0, 0, '', 2, '2022-12-18 13:31:03', '2022-12-18 13:31:15', 1, 1, '', '2022-12-18', 6, 1, 2, '', '', '', 0, 0),
(189, 'RQC-0007', 7, 0, 0, 0, 0, 0, 0, '', 2, '2022-12-18 13:52:09', '2022-12-18 13:56:53', 1, 1, '', '2022-12-18', 4, 5, 3, '', '', '', 0, 0),
(190, 'RQC-0008', 7, 0, 0, 0, 0, 0, 0, '', 2, '2022-12-18 18:03:05', '2022-12-18 18:06:19', 1, 1, '', '2022-12-18', 4, 5, 3, '', '', '', 1, 1),
(191, 'RQC-0009', 7, 0, 0, 0, 0, 0, 0, '', 2, '2022-12-18 18:37:24', '2022-12-18 18:37:29', 1, 1, '', '2022-12-18', 6, 3, 3, '', '', '', 1, 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `receiving_list`
--

CREATE TABLE IF NOT EXISTS `receiving_list` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `form_id` int(30) NOT NULL,
  `from_order` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1=PO ,2 = BO',
  `amount` float NOT NULL DEFAULT 0,
  `discount_perc` float NOT NULL DEFAULT 0,
  `discount` float NOT NULL DEFAULT 0,
  `tax_perc` float NOT NULL DEFAULT 0,
  `tax` float NOT NULL DEFAULT 0,
  `stock_ids` text DEFAULT NULL,
  `remarks` text DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `data_aprovacao` date DEFAULT NULL,
  `nome_aprovacao` varchar(30) NOT NULL,
  `estado_requisicao` tinyint(2) NOT NULL,
  `data_autorizacao` date DEFAULT NULL,
  `nome_autorizacao` varchar(50) NOT NULL,
  `numero_omie` varchar(50) NOT NULL,
  `nf_chegada` varchar(50) NOT NULL,
  `data_chegada` date DEFAULT NULL,
  `req_aprov` tinyint(2) NOT NULL,
  `req_aprov2` tinyint(2) NOT NULL,
  `etapa_autorizacao` tinyint(2) NOT NULL,
  `etapa_cotacao` tinyint(2) NOT NULL,
  `etapa_aprovacao` tinyint(2) NOT NULL,
  `etapa_omie` tinyint(2) NOT NULL,
  `etapa_chegada` tinyint(2) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=130 DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `receiving_list`
--

INSERT INTO `receiving_list` (`id`, `form_id`, `from_order`, `amount`, `discount_perc`, `discount`, `tax_perc`, `tax`, `stock_ids`, `remarks`, `date_created`, `date_updated`, `data_aprovacao`, `nome_aprovacao`, `estado_requisicao`, `data_autorizacao`, `nome_autorizacao`, `numero_omie`, `nf_chegada`, `data_chegada`, `req_aprov`, `req_aprov2`, `etapa_autorizacao`, `etapa_cotacao`, `etapa_aprovacao`, `etapa_omie`, `etapa_chegada`) VALUES
(121, 183, 1, 0, 0, 0, 0, 0, '325', '', '2022-12-14 21:00:29', '2022-12-14 21:03:11', '2022-12-14', 'Raul Dias', 4, '2022-12-14', 'Raul Dias', 'x', '', NULL, 1, 1, 0, 0, 0, 0, 0),
(122, 184, 1, 0, 0, 0, 0, 0, '329', '', '2022-12-14 21:03:59', '2022-12-14 21:10:29', '2022-12-14', 'Raul Dias', 4, '2022-12-14', 'Raul Dias', 's', '', NULL, 1, 1, 0, 0, 0, 0, 0),
(123, 185, 1, 0, 0, 0, 0, 0, '333', '', '2022-12-14 21:12:13', '2022-12-14 21:14:24', '2022-12-14', 'Raul Dias', 4, '2022-12-14', 'Raul Dias', 'sd', '', NULL, 1, 1, 0, 0, 0, 0, 0),
(124, 186, 1, 0, 0, 0, 0, 0, '334', '', '2022-12-18 12:33:56', '2022-12-18 12:33:56', NULL, '', 1, '2022-12-18', 'Raul Dias', '', '', NULL, 0, 0, 0, 0, 0, 0, 0),
(125, 187, 1, 0, 0, 0, 0, 0, '339,340', '', '2022-12-18 12:36:51', '2022-12-18 13:22:25', '2022-12-18', 'Raul Dias', 3, '2022-12-18', 'Raul Dias', '', '', NULL, 1, 1, 0, 0, 0, 0, 0),
(126, 188, 1, 0, 0, 0, 0, 0, '345,346', '', '2022-12-18 13:31:15', '2022-12-18 13:39:56', '2022-12-18', 'Raul Dias', 3, '2022-12-18', 'Raul Dias', '', '', NULL, 1, 1, 0, 0, 0, 0, 0),
(127, 189, 1, 0, 0, 0, 0, 0, '351', '', '2022-12-18 13:56:53', '2022-12-18 14:09:06', '2022-12-18', 'Raul Dias', 5, '2022-12-18', 'Raul Dias', 'fsdsfd', 'nff', '1995-07-18', 1, 1, 0, 0, 0, 0, 0),
(128, 190, 1, 0, 0, 0, 0, 0, '359', '', '2022-12-18 18:06:19', '2022-12-18 18:45:19', '2022-12-18', 'Raul Dias', 5, '2022-12-18', 'Raul Dias', '124578', 'nf1', '1995-07-18', 1, 1, 1, 1, 1, 1, 1),
(129, 191, 1, 0, 0, 0, 0, 0, '357', '', '2022-12-18 18:37:29', '2022-12-18 18:39:21', '2022-12-18', 'Raul Dias', 3, '2022-12-18', 'Raul Dias', '', '', NULL, 1, 0, 1, 1, 1, 0, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `requisitante_list`
--

CREATE TABLE IF NOT EXISTS `requisitante_list` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `requisitante_list`
--

INSERT INTO `requisitante_list` (`id`, `name`, `status`, `date_created`, `date_updated`) VALUES
(3, 'Raul', 1, '2022-11-18 08:28:50', '2022-11-25 08:41:25'),
(4, 'Fernando', 1, '2022-11-18 08:28:50', '2022-11-25 08:41:31'),
(5, 'Marcelo', 1, '2022-11-25 08:41:39', '2022-11-25 08:41:39'),
(6, 'Isabela', 1, '2022-11-25 08:41:46', '2022-11-25 08:41:46');

-- --------------------------------------------------------

--
-- Estrutura da tabela `return_list`
--

CREATE TABLE IF NOT EXISTS `return_list` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `return_code` varchar(50) NOT NULL,
  `supplier_id` int(30) NOT NULL,
  `amount` float NOT NULL DEFAULT 0,
  `remarks` text DEFAULT NULL,
  `stock_ids` text NOT NULL,
  `re_solicitante` text DEFAULT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `supplier_id` (`supplier_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `sales_list`
--

CREATE TABLE IF NOT EXISTS `sales_list` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `sales_code` varchar(50) NOT NULL,
  `client` text DEFAULT NULL,
  `amount` float NOT NULL DEFAULT 0,
  `remarks` text DEFAULT NULL,
  `stock_ids` text NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Estrutura da tabela `seitem_list`
--

CREATE TABLE IF NOT EXISTS `seitem_list` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `description` text NOT NULL,
  `cod_item` varchar(50) DEFAULT NULL,
  `supplier_id` int(30) NOT NULL,
  `cost` float NOT NULL DEFAULT 0,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `supplier_id` (`supplier_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `seitem_list`
--

INSERT INTO `seitem_list` (`id`, `name`, `description`, `cod_item`, `supplier_id`, `cost`, `status`, `date_created`, `date_updated`) VALUES
(1, 'serviço item', 'teste desc', 'ser-5542', 1, 100, 1, '2022-10-25 14:30:27', '2022-10-25 14:31:07');

-- --------------------------------------------------------

--
-- Estrutura da tabela `sepo_items`
--

CREATE TABLE IF NOT EXISTS `sepo_items` (
  `po_id` int(30) NOT NULL,
  `item_id` int(30) NOT NULL,
  `quantity` int(30) NOT NULL,
  `price` float NOT NULL DEFAULT 0,
  `unit` varchar(50) NOT NULL,
  `total` float NOT NULL DEFAULT 0,
  KEY `po_id` (`po_id`),
  KEY `item_id` (`item_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `sepo_items`
--

INSERT INTO `sepo_items` (`po_id`, `item_id`, `quantity`, `price`, `unit`, `total`) VALUES
(1, 1, 100, 100, 'm', 10000),
(2, 1, 100, 100, 'm', 10000),
(3, 1, 100, 100, 'm', 10000);

-- --------------------------------------------------------

--
-- Estrutura da tabela `sepurchase_order_list`
--

CREATE TABLE IF NOT EXISTS `sepurchase_order_list` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `po_code` varchar(50) NOT NULL,
  `supplier_id` int(30) NOT NULL,
  `amount` float NOT NULL,
  `discount_perc` float NOT NULL DEFAULT 0,
  `discount` float NOT NULL DEFAULT 0,
  `tax_perc` float NOT NULL DEFAULT 0,
  `tax` float NOT NULL DEFAULT 0,
  `remarks` text NOT NULL,
  `status` tinyint(4) NOT NULL DEFAULT 0 COMMENT '0 = pending, 1 = partially received, 2 =received',
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  `unidade_req` tinyint(1) NOT NULL DEFAULT 1,
  `projeto_op` tinyint(1) NOT NULL DEFAULT 1,
  `sepo_code` varchar(50) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `supplier_id` (`supplier_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `sepurchase_order_list`
--

INSERT INTO `sepurchase_order_list` (`id`, `po_code`, `supplier_id`, `amount`, `discount_perc`, `discount`, `tax_perc`, `tax`, `remarks`, `status`, `date_created`, `date_updated`, `unidade_req`, `projeto_op`, `sepo_code`) VALUES
(1, 'ENT-0001', 1, 10000, 0, 0, 0, 0, '', 0, '2022-10-25 14:31:16', '2022-10-25 14:31:16', 1, 1, ''),
(2, 'ENT-0002', 1, 10000, 0, 0, 0, 0, '', 0, '2022-10-25 14:40:53', '2022-10-25 14:40:53', 1, 1, ''),
(3, 'SER-0001', 1, 10000, 0, 0, 0, 0, '', 0, '2022-10-26 20:54:27', '2022-10-26 20:54:27', 1, 1, '');

-- --------------------------------------------------------

--
-- Estrutura da tabela `sesupplier_list`
--

CREATE TABLE IF NOT EXISTS `sesupplier_list` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `address` text NOT NULL,
  `cperson` text NOT NULL,
  `contact` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `sesupplier_list`
--

INSERT INTO `sesupplier_list` (`id`, `name`, `address`, `cperson`, `contact`, `status`, `date_created`, `date_updated`) VALUES
(1, 'Categoria serviço', '', '', '', 1, '2022-10-25 14:29:50', '2022-10-25 14:29:50');

-- --------------------------------------------------------

--
-- Estrutura da tabela `setor_list`
--

CREATE TABLE IF NOT EXISTS `setor_list` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `setor_list`
--

INSERT INTO `setor_list` (`id`, `name`, `status`, `date_created`, `date_updated`) VALUES
(1, 'Operacional', 1, '2022-10-26 11:56:11', '2022-11-25 08:44:37'),
(2, 'Administrativo', 1, '2022-10-26 11:56:11', '2022-11-25 08:44:48'),
(3, 'Financeiro', 1, '2022-11-25 08:45:03', '2022-11-25 08:45:03'),
(4, 'Negócios', 1, '2022-11-25 08:45:14', '2022-11-25 08:45:14');

-- --------------------------------------------------------

--
-- Estrutura da tabela `stock_list`
--

CREATE TABLE IF NOT EXISTS `stock_list` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `item_id` int(30) NOT NULL,
  `quantity` int(30) NOT NULL,
  `unit` varchar(250) DEFAULT NULL,
  `price` float NOT NULL DEFAULT 0,
  `total` float NOT NULL DEFAULT current_timestamp(),
  `type` tinyint(1) NOT NULL DEFAULT 1 COMMENT '1=IN , 2=OUT',
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `cotacao_1_0` varchar(50) NOT NULL,
  `cotacao_1_1` double NOT NULL,
  `cotacao_1_2` double NOT NULL,
  `cotacao_2_0` varchar(50) NOT NULL,
  `cotacao_2_1` double NOT NULL,
  `cotacao_2_2` double NOT NULL,
  `cotacao_3_0` varchar(50) NOT NULL,
  `cotacao_3_1` double NOT NULL,
  `cotacao_3_2` double NOT NULL,
  `botao_cot1` tinyint(2) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `item_id` (`item_id`)
) ENGINE=InnoDB AUTO_INCREMENT=360 DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `stock_list`
--

INSERT INTO `stock_list` (`id`, `item_id`, `quantity`, `unit`, `price`, `total`, `type`, `date_created`, `cotacao_1_0`, `cotacao_1_1`, `cotacao_1_2`, `cotacao_2_0`, `cotacao_2_1`, `cotacao_2_2`, `cotacao_3_0`, `cotacao_3_1`, `cotacao_3_2`, `botao_cot1`) VALUES
(325, 65, 55, 'Caixa', 0, 0, 1, '2022-12-14 21:03:11', 'f1', 100, 100, 'f2', 200, 200, 'f3', 300, 300, 2),
(329, 65, 55, 'Und', 0, 0, 1, '2022-12-14 21:10:29', 'f1', 100, 100, 'f2', 200, 200, 'f3', 300, 300, 2),
(333, 65, 55, 'M', 0, 0, 1, '2022-12-14 21:14:24', 'f1', 100, 100, 'f2', 200, 200, 'f3', 300, 300, 1),
(334, 65, 5, 'Caixa', 0, 0, 1, '2022-12-18 12:33:56', '', 0, 0, '', 0, 0, '', 0, 0, 0),
(339, 65, 6, 'Caixa', 0, 0, 1, '2022-12-18 13:22:25', 'f1', 1, 1, 'f2', 2, 2, 'f3', 3, 3, 2),
(340, 66, 4, 'Und', 0, 0, 1, '2022-12-18 13:22:25', 'f4', 4, 4, 'f5', 5, 5, 'f6', 6, 6, 1),
(345, 65, 55, 'Caixa', 0, 0, 1, '2022-12-18 13:39:56', 'f1', 1, 1, 'f2', 2, 2, 'f3', 3, 3, 1),
(346, 66, 55, 'Und', 0, 0, 1, '2022-12-18 13:39:56', 'f4', 4, 4, 'f5', 5, 5, 'f6', 6, 6, 2),
(351, 65, 5, 'Und', 0, 0, 1, '2022-12-18 14:09:06', 'f1', 1, 1, 'f2', 2, 2, 'f3', 3, 3, 0),
(357, 65, 5, 'Cm', 0, 0, 1, '2022-12-18 18:39:21', 'f1', 1, 1, 'f2', 2, 2, 'f3', 3, 3, 0),
(359, 65, 4, 'Und', 0, 0, 1, '2022-12-18 18:45:19', 'f1', 1, 1, 'f2', 2, 2, 'f3', 3, 3, 0);

-- --------------------------------------------------------

--
-- Estrutura da tabela `supplier_list`
--

CREATE TABLE IF NOT EXISTS `supplier_list` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `name` text NOT NULL,
  `address` text NOT NULL,
  `cperson` text NOT NULL,
  `contact` text NOT NULL,
  `status` tinyint(1) NOT NULL DEFAULT 1,
  `mat_ou_ser` tinyint(1) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime NOT NULL DEFAULT current_timestamp() ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `supplier_list`
--

INSERT INTO `supplier_list` (`id`, `name`, `address`, `cperson`, `contact`, `status`, `mat_ou_ser`, `date_created`, `date_updated`) VALUES
(7, 'Informática', '', '', '', 1, 1, '2022-10-06 09:20:21', '2022-11-25 08:38:54'),
(8, 'Instalação', '', '', '', 1, 0, '2022-11-09 11:58:02', '2022-11-25 08:54:28'),
(9, 'Matéria Prima', '', '', '', 1, 1, '2022-11-17 13:02:50', '2022-11-25 08:54:15'),
(10, 'Manutenção', '', '', '', 1, 0, '2022-11-25 08:39:16', '2022-11-25 08:39:16');

-- --------------------------------------------------------

--
-- Estrutura da tabela `system_info`
--

CREATE TABLE IF NOT EXISTS `system_info` (
  `id` int(30) NOT NULL AUTO_INCREMENT,
  `meta_field` text NOT NULL,
  `meta_value` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `system_info`
--

INSERT INTO `system_info` (`id`, `meta_field`, `meta_value`) VALUES
(1, 'name', 'PROTÓTIPO SISTEMA'),
(6, 'short_name', 'ROBOFLEX'),
(11, 'logo', 'uploads/logo-1664192203.png'),
(13, 'user_avatar', 'uploads/user_avatar.jpg'),
(14, 'cover', 'uploads/cover-1666355297.png'),
(15, 'content', 'Array');

-- --------------------------------------------------------

--
-- Estrutura da tabela `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `id` int(50) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(250) NOT NULL,
  `middlename` text DEFAULT NULL,
  `lastname` varchar(250) NOT NULL,
  `username` text NOT NULL,
  `password` text NOT NULL,
  `avatar` text DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `type` tinyint(1) NOT NULL DEFAULT 0,
  `date_added` datetime NOT NULL DEFAULT current_timestamp(),
  `date_updated` datetime DEFAULT NULL ON UPDATE current_timestamp(),
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4;

--
-- Extraindo dados da tabela `users`
--

INSERT INTO `users` (`id`, `firstname`, `middlename`, `lastname`, `username`, `password`, `avatar`, `last_login`, `type`, `date_added`, `date_updated`) VALUES
(13, 'Raul', NULL, 'Dias', 'Raul', '8c4653350d7cb59e1da53d08c2f75a54', NULL, NULL, 1, '2022-09-28 08:46:55', '2022-11-17 14:08:05'),
(14, 'teste', NULL, 'teste', 'usuario', 'f8032d5cae3de20fcec887f395ec9a6a', NULL, NULL, 3, '2022-10-21 09:30:48', '2022-11-25 14:04:54'),
(15, 'Gabrielle', NULL, 'Freitas', 'Gabrielle', '202cb962ac59075b964b07152d234b70', NULL, NULL, 1, '2022-11-25 09:13:11', NULL);

-- --------------------------------------------------------

--
-- Estrutura da tabela `user_meta`
--

CREATE TABLE IF NOT EXISTS `user_meta` (
  `user_id` int(30) NOT NULL,
  `meta_field` text NOT NULL,
  `meta_value` text NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp(),
  KEY `user_id` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Restrições para despejos de tabelas
--

--
-- Limitadores para a tabela `back_order_list`
--
ALTER TABLE `back_order_list`
  ADD CONSTRAINT `back_order_list_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `supplier_list` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `back_order_list_ibfk_2` FOREIGN KEY (`po_id`) REFERENCES `purchase_order_list` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `back_order_list_ibfk_3` FOREIGN KEY (`receiving_id`) REFERENCES `receiving_list` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `bo_items`
--
ALTER TABLE `bo_items`
  ADD CONSTRAINT `bo_items_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `item_list` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `bo_items_ibfk_2` FOREIGN KEY (`bo_id`) REFERENCES `back_order_list` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `cotacao_list`
--
ALTER TABLE `cotacao_list`
  ADD CONSTRAINT `cotacao_chave_1` FOREIGN KEY (`po_id`) REFERENCES `purchase_order_list` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `cotacao_chave_2` FOREIGN KEY (`item_id`) REFERENCES `item_list` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `fornecedor_list`
--
ALTER TABLE `fornecedor_list`
  ADD CONSTRAINT `fornecedor_cat_fsk` FOREIGN KEY (`fornecedor_cat_id`) REFERENCES `fornecedor_cat` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `item_list`
--
ALTER TABLE `item_list`
  ADD CONSTRAINT `item_list_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `supplier_list` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `po_items`
--
ALTER TABLE `po_items`
  ADD CONSTRAINT `po_items_ibfk_1` FOREIGN KEY (`po_id`) REFERENCES `purchase_order_list` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `po_items_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `item_list` (`id`);

--
-- Limitadores para a tabela `purchase_order_list`
--
ALTER TABLE `purchase_order_list`
  ADD CONSTRAINT `purchase_order_list_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `supplier_list` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `return_list`
--
ALTER TABLE `return_list`
  ADD CONSTRAINT `return_list_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `supplier_list` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `seitem_list`
--
ALTER TABLE `seitem_list`
  ADD CONSTRAINT `seitem_list_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `sesupplier_list` (`id`);

--
-- Limitadores para a tabela `sepo_items`
--
ALTER TABLE `sepo_items`
  ADD CONSTRAINT `sepo_items_ibfk_1` FOREIGN KEY (`po_id`) REFERENCES `sepurchase_order_list` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `sepo_items_ibfk_2` FOREIGN KEY (`item_id`) REFERENCES `seitem_list` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `sepurchase_order_list`
--
ALTER TABLE `sepurchase_order_list`
  ADD CONSTRAINT `sepurchase_order_list_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `sesupplier_list` (`id`) ON DELETE CASCADE;

--
-- Limitadores para a tabela `stock_list`
--
ALTER TABLE `stock_list`
  ADD CONSTRAINT `stock_list_ibfk_1` FOREIGN KEY (`item_id`) REFERENCES `item_list` (`id`) ON DELETE CASCADE;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
